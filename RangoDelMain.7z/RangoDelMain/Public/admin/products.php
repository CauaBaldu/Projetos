<?php
include '../../config/database.php';
session_start();

if (!isset($_SESSION['user_id'])) {
    header('Location: ../login.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_product'])) {
    $name = $_POST['name'];
    $description = $_POST['description'];
    $price = $_POST['price'];

    $stmt = $pdo->prepare("INSERT INTO products (name, description, price) VALUES (?, ?, ?)");
    if ($stmt->execute([$name, $description, $price])) {
        $success = 'Produto adicionado com sucesso!';
    } else {
        $error = 'Falha ao adicionar produto.';
    }
}

if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    $stmt = $pdo->prepare("DELETE FROM products WHERE id = ?");
    if ($stmt->execute([$id])) {
        $success = 'Produto excluído com sucesso!';
    } else {
        $error = 'Falha ao excluir produto.';
    }
}

$stmt = $pdo->query("SELECT * FROM products");
$products = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Administração de Produtos</title>
    <link rel="stylesheet" href="../css/styles.css">
</head>
<body>
    <header>
        <h1>Administração de Produtos</h1>
    </header>
    <div class="container">
        <?php if (isset($error)): ?>
            <p class="error"><?php echo $error; ?></p>
        <?php endif; ?>
        <?php if (isset($success)): ?>
            <p class="success"><?php echo $success; ?></p>
        <?php endif; ?>

        <h2>Adicionar Novo Produto</h2>
        <form method="post">
            <input type="hidden" name="add_product" value="1">
            <label for="name">Nome:</label>
            <input type="text" name="name" id="name" required>
            <br>
            <label for="description">Descrição:</label>
            <textarea name="description" id="description" required></textarea>
            <br>
            <label for="price">Preço:</label>
            <input type="number" step="0.01" name="price" id="price" required>
            <br>
            <input type="submit" value="Adicionar Produto">
        </form>

        <h2>Produtos Existentes</h2>
        <div class="table-container">
            <table>
                <tr>
                    <th>ID</th>
                    <th>Nome</th>
                    <th>Descrição</th>
                    <th>Preço</th>
                    <th>Ações</th>
                </tr>
                <?php foreach ($products as $product): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($product['id']); ?></td>
                        <td><?php echo htmlspecialchars($product['name']); ?></td>
                        <td><?php echo htmlspecialchars($product['description']); ?></td>
                        <td>R$<?php echo htmlspecialchars($product['price']); ?></td>
                        <td>
                            <a href="edit_product.php?id=<?php echo $product['id']; ?>" class="button">Editar</a> |
                            <a href="?delete=<?php echo $product['id']; ?>" class="button" onclick="return confirm('Tem certeza que deseja excluir este produto?')">Excluir</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </table>
        </div>
    </div>
</body>
</html>
