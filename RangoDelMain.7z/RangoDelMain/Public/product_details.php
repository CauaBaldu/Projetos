<?php
include '../config/database.php';

if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $stmt = $pdo->prepare("SELECT * FROM products WHERE id = ?");
    $stmt->execute([$id]);
    $product = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$product) {
        die('Produto não encontrado.');
    }
} else {
    die('ID do produto não especificado.');
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Detalhes do Produto - Rango do Rei</title>
    <link rel="stylesheet" href="css/styles.css">
    <style>
        .product-details {
            background: #fff;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            margin: 20px 0;
            text-align: center;
        }

        .product-details img {
            width: 100%;
            max-width: 600px;
            height: auto;
            border-radius: 5px;
            margin-bottom: 20px;
        }

        .product-details h1 {
            margin-top: 0;
        }

        .price {
            color: #007bff;
            font-size: 1.5em;
            margin: 10px 0;
        }

        .description {
            margin: 20px 0;
        }

        .back-button {
            background: #007bff;
            color: #fff;
            padding: 10px 20px;
            border-radius: 5px;
            text-decoration: none;
            cursor: pointer;
        }

        .back-button:hover {
            background: #0056b3;
        }
    </style>
</head>
<body>
    <header>
        <h1>Detalhes do Produto</h1>
    </header>
    <div class="container">
        <div class="product-details">
            <img src="https://source.unsplash.com/600x400/?food" alt="Imagem do Produto">
            <h1><?php echo htmlspecialchars($product['name']); ?></h1>
            <div class="price">R$<?php echo htmlspecialchars($product['price']); ?></div>
            <div class="description"><?php echo htmlspecialchars($product['description']); ?></div>
            <a href="products.php" class="back-button">Voltar para Lista de Produtos</a>
        </div>
    </div>
</body>
</html>
