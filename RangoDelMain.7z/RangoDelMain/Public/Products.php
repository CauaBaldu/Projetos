<?php
include '../config/database.php';
?>
<!DOCTYPE html>
<html>
<head>
    <title>Produtos - Rango do Rei</title>
    <link rel="stylesheet" href="css/styles.css">
    <style>
        .product-card {
            background: #fff;
            border: 1px solid #ddd;
            border-radius: 5px;
            padding: 15px;
            margin: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            text-align: center;
            transition: transform 0.3s ease;
            width: 300px;
        }

        .product-card:hover {
            transform: scale(1.05);
        }

        .product-image {
            width: 100%;
            height: auto;
            border-radius: 5px;
        }

        .product-name {
            font-size: 1.2em;
            margin: 10px 0;
        }

        .product-price {
            color: #007bff;
            font-size: 1.1em;
            margin-bottom: 10px;
        }

        .product-description {
            font-size: 0.9em;
            color: #666;
            margin-bottom: 10px;
        }

        .view-details {
            background: #007bff;
            color: #fff;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            text-decoration: none;
            cursor: pointer;
        }

        .view-details:hover {
            background: #0056b3;
        }

        .products-container {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
        }
    </style>
</head>
<body>
    <header>
        <h1>Lista de Produtos</h1>
    </header>
    <div class="container">
        <div class="products-container">
            <?php
            $stmt = $pdo->query("SELECT * FROM products");
            $products = $stmt->fetchAll(PDO::FETCH_ASSOC);

            foreach ($products as $product): ?>
                <div class="product-card">
                    <img src="https://source.unsplash.com/300x200/?food" alt="Imagem do Produto" class="product-image">
                    <div class="product-name"><?php echo htmlspecialchars($product['name']); ?></div>
                    <div class="product-price">R$<?php echo htmlspecialchars($product['price']); ?></div>
                    <div class="product-description"><?php echo htmlspecialchars($product['description']); ?></div>
                    <a href="product_details.php?id=<?php echo $product['id']; ?>" class="view-details">Ver Detalhes</a>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</body>
</html>
