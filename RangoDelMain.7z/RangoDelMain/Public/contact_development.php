<!DOCTYPE html>
<html>
<head>
    <title>Contato para Desenvolvimento</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
    <h1>Entre em Contato para Desenvolvimento de Sites</h1>
    <form action="send_contact.php" method="POST">
        <input type="text" name="name" placeholder="Seu Nome" required>
        <input type="email" name="email" placeholder="Seu Email" required>
        <textarea name="message" placeholder="Descreva seu projeto" required></textarea>
        <button type="submit">Enviar</button>
    </form>
    <a href="index.php" class="button">Voltar ao Início</a>
</body>
</html>
