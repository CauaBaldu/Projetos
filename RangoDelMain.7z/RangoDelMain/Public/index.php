<!DOCTYPE html>
<html>
<head>
    <title>Rango do Rei</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
    <header>
        <h1>Bem-vindo ao Rango do Rei!</h1>
    </header>
    <div class="container">
        <nav>
            <a href="login.php">Login</a>
            <a href="register.php">Cadastro</a>
            <a href="contact.php">Contato</a>
            <a href="products.php">Produtos</a>
            <?php if (isset($_SESSION['user_id'])): ?>
                <a href="admin/products.php">Administração de Produtos</a>
                <a href="admin/orders.php">Listagem de Pedidos</a>
            <?php endif; ?>
        </nav>
    </div>
</body>
</html>
