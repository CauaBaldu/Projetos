<!DOCTYPE html>
<html>
<head>
    <title>Créditos</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
    <h1>Créditos do Site</h1>
    <p>Este site foi desenvolvido por:</p>
    <ul>
        <li>Nome do Criador 1</li>
        <li>Nome do Criador 2</li>
        <li>Nome do Criador 3</li>
    </ul>
    <a href="index.php" class="button">Voltar ao Início</a>
</body>
</html>
