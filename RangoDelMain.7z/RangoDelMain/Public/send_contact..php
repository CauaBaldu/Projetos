<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = filter_input(INPUT_POST, 'name', FILTER_SANITIZE_STRING);
    $email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL);
    $message = filter_input(INPUT_POST, 'message', FILTER_SANITIZE_STRING);

    // Aqui você pode adicionar a lógica para enviar um email ou salvar no banco de dados
    // Por exemplo, usando mail() ou um serviço de envio de emails

    // Redirecionar ou exibir uma mensagem de sucesso
    header("Location: index.php?success=1");
    exit();
}
?>
