<!DOCTYPE html>
<html>
<head>
    <title>Contato</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
    <header>
        <h1>Contato</h1>
    </header>
    <div class="container">
        <form method="post" action="send_contact.php">
            <label for="name">Nome:</label>
            <input type="text" name="name" id="name" required>
            <br>
            <label for="email">E-mail:</label>
            <input type="email" name="email" id="email" required>
            <br>
            <label for="message">Mensagem:</label>
            <textarea name="message" id="message" required></textarea>
            <br>
            <input type="submit" value="Enviar">
        </form>
    </div>
</body>
</html>
<?php
include '../config/database.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $message = $_POST['message'];

    $stmt = $pdo->prepare("INSERT INTO contacts (name, email, message) VALUES (?, ?, ?)");
    if ($stmt->execute([$name, $email, $message])) {
        $success = 'Mensagem enviada com sucesso!';
    } else {
        $error = 'Falha ao enviar a mensagem.';
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Contato - Rango do Rei</title>
    <link rel="stylesheet" href="css/styles.css">
    <style>
        .contact-form {
            background: #fff;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            max-width: 600px;
            margin: 20px auto;
        }

        .contact-form input, .contact-form textarea {
            width: 100%;
            padding: 10px;
            margin: 10px 0;
            border: 1px solid #ddd;
            border-radius: 5px;
        }

        .contact-form input[type="submit"] {
            background: #007bff;
            color: #fff;
            border: none;
       
