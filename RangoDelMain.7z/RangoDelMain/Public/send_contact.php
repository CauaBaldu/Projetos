<?php
include '../config/database.php';
?>
<!DOCTYPE html>
<html>
<head>
    <title>Produtos</title>
</head>
<body>
    <h1>Lista de Produtos</h1>
    <?php
    $stmt = $pdo->query("SELECT * FROM products");
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        echo '<div>';
        echo '<h2>' . htmlspecialchars($row['name']) . '</h2>';
        echo '<p>' . htmlspecialchars($row['description']) . '</p>';
        echo '<p>Preço: R$' . htmlspecialchars($row['price']) . '</p>';
        echo '</div>';
    }
    ?>
</body>
</html>
