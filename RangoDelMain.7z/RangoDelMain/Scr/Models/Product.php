<?php
namespace Models;

class Product {
    public static function getPrices() {
        // Exemplo de preços. Em um caso real, você obteria isso de um banco de dados.
        return [
            1 => 3.50, // Salgado 1
            2 => 4.00, // Salgado 2
            3 => 2.50  // Salgado 3
        ];
    }
}


