<?php
$host = 'localhost';
$dbname = 'rango_do_rei';
$username = 'root'; // ou seu usuário MySQL
$password = ''; // ou sua senha MySQL

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo 'Connection failed: ' . $e->getMessage();
}
?>
